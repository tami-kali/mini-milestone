This folder contains the source for Milestone 3
